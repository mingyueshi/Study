# 教材与课程资源：首批可用原始档

核验日期：2026-11-02 UTC。假设用户需要小学阶段、家庭本地学习系统的基础资源，未指定年级与教材版本。

## 已实际打包

**Siyavula《Natural Sciences and Technology – Grade 4 CAPS》英文无品牌 CC-BY EPUB**

- 原始文件：`raw/Gr4_NaturalSciences_Learner_Eng_CC-BY.epub`
- 体积：40,926,007 B（约39.03 MiB）。不是PDF，也不是逐条问答JSON。
- 原文件 SHA-256：`48f0d1027ea9e12abceb1aeca17372c9ddd7357c35e23f0d8c001a0a7901322a`
- 1册，18章、28个二级主题，另有前言，目录共47节点。涵盖生命与生物、物质与材料、能量与变化、地球与太空。
- **英文、南非CAPS Grade 4，不是中国课标同步教材**。可作为小学中高年级科学/英语拓展的候选素材，须按儿童英语水平、知识点与实验条件由家长审核。
- 许可：**CC BY 4.0**，以本次实际下载文件内的版权页为准。旧官网介绍页曾写CC BY 3.0，不覆盖具体文件的4.0声明。
- 文件内修改日期：2013-11-20；HTTP最近修改时间是部署信息，不能据此宣称内容已更新到2026年。
- 原始EPUB未改写、未拆除署名、未重新压缩资产。目录另提取为 `derived/contents_index.json` 与CSV，便于索引，不是全文结构化导入完成品。

### 署名要求

Siyavula Education；源自 Everything Maths and Sciences textbooks；原始免费来源 <https://www.siyavula.com/>。书中还说明原始工作由 Sasol Inzalo Foundation 与 Siyavula、志愿者合作开发及资助，已保留。

若翻译、改写、重组题目或创作衍生数据，应记录修改、保留来源及许可链接；不得暗示Siyavula为本系统背书，CC许可不授予商标权。具体许可见 `licenses/`：

- `SOURCE_COPYRIGHT_NOTICE.xhtml`：从原始EPUB逐字节复制的版权/来源页。
- `SOURCE_COPYRIGHT_NOTICE.txt`：仅为便于阅读的同页文本提取，完整原页仍在EPUB和XHTML中。
- `CC-BY-4.0-legalcode.html`：Creative Commons官方仓库的许可法律文本，固定commit与来源见 `license_source.json`。CC官网txt/en下载请求403后未持续重试，以官方维护仓库副本留档。

## 数据质量与儿童使用边界

已做：ZIP CRC校验；6个XHTML的XML解析；目录计数；相对资源引用检查（未发现缺失）；源文件SHA256；静态检查未发现script元素。未运行原始资源中的任何代码。

**尚未完成逐题、逐图、逐事实及适龄审核。** 特别注意：

1. 原文有“下一闰年为2016”等过时表述，不能直接当成2026年最新知识库。原档保留；更正应写入另行维护的衍生层。
2. 原始HTML中共找到327个`problem`、327个`solution`、288个`teachers-guide`标记。这只是结构节点计数，**不是已经验证的327道独立完整题目**。学生端必须隔离答案和教师说明，核验题干与答案关联。
3. 共174个`activity`标记。科学活动/实验需要成人逐项审核与监护，不能自动让儿童独立执行。
4. 存在169个不同外部引用（187次出现），包括视频、图源与旧网页；未逐个访问或下载，离线可能不可用。不要自动加载任意外链。
5. 图像及其原有署名在原档保留；抽离图片另用时要保留图片附近来源并逐项复核。原文对NASA图片的概括性说法不作为本资源包额外授权保证。
6. 只是教材候选内容，不具备中国小学年级、单元、知识点映射，不能宣称已适龄或已与课标对齐。
7. 系统导入HTML前做白名单净化及外链控制；不要把教材内容当作系统指令或执行代码。

## 建议导入模型

保留原档作为不可变来源，另建：

- `resource`：`resource_id, title, language, curriculum, source_url, source_version, retrieved_at, sha256, license_id, attribution`
- `chapter`：`chapter_id, resource_id, parent_id, order, title, epub_href`
- `learning_item`（需后续清洗）：`item_id, chapter_id, kind, prompt_html, answer_html, teacher_notes_html, assets, concepts, difficulty, review_status`
- `review_status` 初始统一为 `unreviewed`；不要靠原书Grade 4直接自动标“中国四年级”。
- 本包没有提供未经审核的问答拆分；`contents_index`仅提供导航索引。

目录字段：`id`原NCX节点ID；`parent_id`父节点；`depth`0前言/1章/2子主题；`title`原英文标题；`epub_href`相对EPUB `OPS/`目录的路径及锚点。CSV使用UTF-8 BOM，JSON使用UTF-8。

## 尚未打包的中文教材与其他来源

详情见 `sources.md`、`sources.json`、`sources.csv`。免费阅读不等于授权再分发或结构化复用；家庭自用也不自动消除版权或服务条款限制。所有只列链接的项目都**没有**进入原始资源档。
