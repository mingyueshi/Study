# 字词、汉字与笔顺首批数据

核验日期：2026-11-02。按小学家庭学习系统选基础数据；没有获知具体年级、地区或教材版次，因此**全部原始条目均未标记“儿童审核通过”**。

| 数据 | 实测规模 | 导入入口 | 用途 |
|---|---:|---|---|
| CC-CEDICT | 125,346词条 | `cc-cedict/normalized/entries.jsonl` | 中英查词、拼音检索、精选词卡；不是中文释义字典 |
| Make Me a Hanzi | 9,574字，两表一一对应 | `makemeahanzi/original/dictionary.txt` 与 `graphics.txt`（都是JSONL） | 字形拆解、笔顺动画、描红；需复核笔顺与教学规范 |
| Unihan 17.0.0 | 102,998码位 | `unihan-17.0.0/normalized/character_properties.jsonl` | 字音/部首/笔画/异体检索后台 |

## 字段与许可
完整字段类型、实际缺口、版本及来源见 `metadata.json`；下载URL与SHA256见各下载记录及总清单。

1. CC-CEDICT 原始导出时间为 **2026-10-31 21:06:18 UTC**，不是按查询时间猜测版本。保留原始gzip、解压TXT、头部与解析报告。JSONL仅格式转换，依CC BY-SA 4.0归属共享。词典包含成人、辱骂、暴力和歧义词等，不应全量随机出题。
2. Make Me a Hanzi：`dictionary.txt` 为 LGPL-3.0-or-later，`graphics.txt` 为 Arphic Public License。保留各自条文，不能改称统一MIT。数据未修改。字源与英文解释是辅助提示，不能替代专业字源、语文教参；原始数据存在58条缺解释、9条无拼音、449条结构带未知符号。
3. Unihan 选择固定 **17.0.0** 作为可复现基线，不声称最新。许多字极罕见。`kGradeLevel`来自香港2001年资料，不是当前大陆课标分级；`kFrequency`已自16.0移除，本版没有此字段记录。`kTotalStrokes`、变体、读音可多值，保留字符串；不要强制单一笔画或一对一繁简映射。

## 推荐入口顺序
先挑一份家长批准的常用字/词白名单 → 联结字音与笔顺 → 小批验证 → 再做全文检索。默认 `review_status=pending`，不要把缺失年级、难度或读音用模型猜值后当官方事实。

## 尚不打包
`chinese-xinhua` 仓库有MIT，但作者明确数据抓自多个网站且侵权即删，无法据此确认现代释义原权利链。本批不重复已存在的30,895条成语，也不扩打包其字典、词语与歇后语。候选与说明见总包索引。

## 来源
- [CC-CEDICT官方授权与下载](https://www.mdbg.net/chinese/dictionary?page=cc-cedict)
- [Make Me a Hanzi官方仓库及分许可说明](https://github.com/skishore/makemeahanzi)
- [Unicode固定17.0.0数据目录](https://www.unicode.org/Public/17.0.0/ucd/)
- [Unihan 17.0.0字段规范](https://www.unicode.org/reports/tr38/tr38-39.html)
- [chinese-xinhua来源声明](https://github.com/pwxcoo/chinese-xinhua#copyright)
