# 古诗文首批：保守筛选正文子集

核验时间：2026-11-02 UTC。用户未指定年级，本包用于小学学习系统的**待审素材层**，不是已审教材或可直接给儿童展示的内容库。没有运行上游仓库代码。

## 交付结果

90 个 JSON 数据文件，加原始 LICENSE/README，共 **31,040,938 字节**（29.60 MiB，未含索引说明）。9个文件保留原始字节，83个是明确标注的派生文件。**不是完整《全唐诗》或《全宋词》，也不宣称最新、最全、无版权风险或全部适龄。**

| 数据组 | 交付数量 | 原始数组数量/结构 |
|---|---:|---|
| 唐诗正文筛选子集 | **52,247 条**，58分片 | 从57,607条中保守排除5,360条 |
| 宋词正文筛选子集 | **20,143 条**，22分片 | 从21,050条中排除907条 |
| 上游名“唐诗三百首” | **358 条** | 原文件366条，排除8条；名称不是数量保证 |
| 上游名“宋词三百首” | **280 条** | 原文件实际280条；未将名称误报为300 |
| 诗经 | 305篇 | JSON数组，保持原件 |
| 楚辞正文子集 | 64条 | 原65条，排除含可疑标记的“昭世”条目 |
| 论语 | 20篇 | 每篇含多个章句，不等同20条名句；保持原件 |
| 千家诗 | 219个题名条目，**226个叶级诗篇** | 其中5个题名含12首子诗，不能只按一层数组读取 |
| 千字文 | 1部、250段 | 另有250段拼音；未逐字复核 |
| 百家姓 | 1部、71段 | 另含438项姓氏/郡望事实表，不是所有姓氏的穷尽目录 |
| 三字经传统版 | 1部、96段 | 古代价值判断需成人解释，不能作现代科学/德育权威 |
| 声律启蒙 | 30韵部 | 去除了来源未独立核实的现代摘要 |

选集、主体库、千家诗有重叠；**不能相加称为不重复作品总数**。逐文件体积、字段、源URL、SHA-256、版本和许可见 `file_manifest.csv`，逐组见 `dataset_summary.csv`。

## 来源、版本与许可

- 唯一上游：[chinese-poetry/chinese-poetry 官方仓库](https://github.com/chinese-poetry/chinese-poetry)；从官方 GitHub/raw 域名下载，未用镜像。
- 固定提交 `b8594f81a89752241442f2ce267d6f66f96704ee`；提交时间 `2026-06-17T01:56:08Z`，为采集时解析到的 master 提交。
- [固定版本 README](https://github.com/chinese-poetry/chinese-poetry/blob/b8594f81a89752241442f2ce267d6f66f96704ee/README.md) 声明 MIT；[LICENSE 原文](https://github.com/chinese-poetry/chinese-poetry/blob/b8594f81a89752241442f2ce267d6f66f96704ee/LICENSE) 随包保存于 `raw/LICENSE`，版权声明为 Copyright (c) 2016 JackeyGao。使用/分发需保留该许可及版权声明。
- 上游说明“数据来源于互联网”，并未提供每篇完整底本/采集链。**古典作品原文通常已超过保护期，不等于现代整理、注释、翻译一并成为公版；MIT仓库声明不是第三方权利担保，家庭自用也不是普遍版权豁免。**
- 本次不收录作者现代传记、现代翻译、排名、图片等资源。源数据部分现代说明混在 `paragraphs` 中，故不能直接将原始全量库按“公版古诗”打包。本包将这些风险记录保守隔离，只提供有限筛选子集。

## 保守处理规则与审核边界

从数组型来源共排除 **6,276 条源记录**（包含不同文件间重复的作品，不是去重后的作品数）。按记录正文检测：

1. 含括号、方括号、校勘标记、`按：/今按`、出版社标记等疑似注释线索，排除整条，而不是猜测注释起止。
2. 正文含 `□` 缺字或 `�` 替换字符，或正文为空，排除整条。
3. 唐诗/宋词单个正文段超过120字符，保守隔离；此规则不应用于本来就是长篇古文的论语/楚辞。
4. 删除保留条目中的 `notes`、`prologue` 字段，以及声律启蒙的现代 `abstract`。
5. 有改动的 JSON 重新序列化；数组派生文件逐条新增 `source_record_index`，记录该条在原始数组中的下标。未改动的来源文件保持原始字节。

上述做法会**过度排除部分带古注/异文或较长的真实古诗**，这是首批宁缺毋滥的取舍。详细规则、原始 SHA-256/Git blob SHA-1、逐文件操作见 `metadata.json`；排除项仅保留来源位置、题目、作者和原因于 `excluded_records.csv`，不打包被排除的正文/注释。原始含可疑注释文件也不随包交付，不能将 `derived/` 当作原始下载。

**规则扫描不是逐篇版权审查，更不是逐篇适龄审查。无标记现代释文、错误题名、断句、拼音、归属、漏字仍可能漏检。** 本包没有宣称过滤后每篇都通过版权/适龄审核。应用侧应默认 `review_status=pending`，经家长/教师选篇并对照可靠底本后再启用。古文含战争、死亡、酒、爱情、宗教及性别/阶层偏见，不应把历史价值判断当现代科学或道德结论。

## 格式与字段

- 数据均为 UTF-8 JSON；CSV索引使用 UTF-8 BOM。可直接解析，不需执行来源脚本。
- 唐诗：`author`、`title`、`paragraphs[]`、`id`（上游UUID）、可选 `tags[]`。派生文件另含 `source_record_index`。
- 宋词：`author`、`rhythmic`（词牌，**不是唯一篇名**）、`paragraphs[]`、可选 `tags[]`；派生文件含 `source_record_index`。本包不保留 `prologue`。
- 诗经：`title/chapter/section/content[]`。
- 楚辞：`title/section/author/content[]`，派生文件增加 `source_record_index`。
- 论语：`chapter/paragraphs[]`；拆章句时保留篇名与原数组位置。
- 千家诗：根 `content[].type` 为文体；`content[].content[]` 为题名项（`chapter/author/paragraphs`）。多数 `paragraphs` 是字符串数组，但5个题名项的 `paragraphs` 是 `{subchapter, paragraphs[]}` 子诗对象数组，需继续展开，叶级共226首。
- 声律启蒙：根 `content[].title` 为卷；`content[].content[]` 是韵部（`chapter/paragraphs[]`）。
- 千字文/百家姓/三字经：根 `title/author/tags/paragraphs[]`；这里 `tags` 是字符串，类型与诗词不同。千字文 `spells[]` 是逐段拼音；百家姓 `origin[].surname/place` 是姓氏/郡望信息。

## 质量提示

- 筛选后唐诗、宋词按“作者+题名/词牌+完整正文”精确比较各仍有4条重复冗余；“唐诗三百首”有1条。未静默删除，以保留源记录对应关系。
- 原始唐诗中有4条空正文、444条含 `□`；原始宋词有879条含 `□`、13条含 `�`。这些正文标记在数组子集已过滤，但其他类型错误可能仍存在。
- 唐诗多繁体、部分其他集偏简体，存在异体字、生僻字、断句和标点差异；保留原文，不进行不可逆简繁替换。
- 有限抽样发现千家诗将《春晓》题作“春眠”；因此题名、标签、朝代、作者、拼音不可未经核对当作考试/默写标准答案。
- 千家诗等嵌套蒙学文件已做结构和正文标记检查；未做逐字校勘。传统文本不得直接充当年级/课程标准映射。

## 建议导入模型

保留 `raw/`、`derived/` 及清单作为不可变来源层，再按需转为统一 JSONL：

```json
{
  "id": "source-commit:source-path:original-index-or-json-pointer",
  "source_dataset": "chinese-poetry",
  "source_commit": "b8594f81a89752241442f2ce267d6f66f96704ee",
  "source_path": "全唐诗/唐诗三百首.json",
  "source_locator": "/0",
  "title": "…",
  "author": "…",
  "dynasty": null,
  "rhythmic": null,
  "original_lines": ["…"],
  "display_lines_simplified": null,
  "tags": [],
  "grade_min": null,
  "grade_max": null,
  "review_status": "pending",
  "license": "MIT (upstream repository declaration)",
  "quality_flags": [],
  "canonical_work_id": null
}
```

- 派生数组用 `source_record_index` 构造原始 `source_locator`；原件用现有数组下标；嵌套数据保留完整JSON Pointer。不要把过滤后的新数组下标误认为原始位置。
- `author+title` 不是唯一键；组诗、同名篇、不同版本会碰撞。正文规范化哈希仅用于候选去重，经人工确认再关联 `canonical_work_id`，保留异文。
- 年级、教材版本、必背映射留空，日后根据用户自有课本/官方目录另建。玩法可做搜索、背诵、飞花令、分行拼图、作者/词牌分类，但评分答案与多音字朗读须先校审。
- 儿童端仅显示审核通过白名单，初次导入不要默认全部启用。

## 文件索引与校验

- `metadata.json`：机器可读固定版本、源/派生统计、过滤规则及操作记录。
- `file_manifest.csv`：逐文件来源、许可、字段、大小、原始/交付 SHA-256。
- `dataset_summary.csv`：逐组规模；`excluded_records.csv`：仅排除定位信息，不含排除正文。
- `source_selection.json`：选择文件的上游 Git tree 元信息。全部原始输入已核对 Git blob SHA-1；交付文件另记 SHA-256。
- `SHA256SUMS`：目录内其余交付文件校验值。
