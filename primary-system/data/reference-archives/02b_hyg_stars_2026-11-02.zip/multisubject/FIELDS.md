# 字段说明与推荐关系模型

所有原始完整字段名列于各目录 `metadata.json`，更详细上游说明保留在 `raw/README*`。文件均为 UTF-8（`source_index.csv` 带 UTF-8 BOM 便于 Excel）；数据 CSV 不带 BOM。CSV 空值保持为空，JSON 缺失值保持 `null`。

## 统一的学习系统侧表（建议，并非已生成课标标签）

`resource_record(resource_id, dataset_id, source_record_id, source_version, subject, language, payload_json, license_id, source_url, review_status, suggested_grade_min, suggested_grade_max, tags)`

- `resource_id` 建议为 `dataset_id:source_record_id`；不能使用单纯展示名称做主键。
- `review_status` 初始 `unreviewed`；年级标签初始 `null`，后续由用户审核。
- 白名单/课程映射独立放 `curriculum_link(resource_id, curriculum_version, grade, unit, reviewer, reviewed_at)`，不要改写原始数据。
- 保持许可证域分离，衍生项有 `derived_from` 与变换记录，避免以为跨表合并后许可消失。

## countries

原始：JSON 数组，一条国家或地区；主键 `cca3`，补充 `cca2`。`name` 对象含英文 common/official 与本地语名称；`translations.zho.common/official` 为中文译名；`capital` 是数组（可能多项或为空）；`region/subregion` 是上游区域；`latlng=[纬度,经度]` 不是边界；`area` 单位平方公里。

`currencies` 是以货币代码为键的对象；`languages` 是以语言代码为键的对象；`tld` 顶级域名数组；`ccn3` 数字代码但应保留字符串前导零；`cioc` 奥委会缩写；`independent`、`unMember` 为上游布尔/空值；`status` 代码分配状态；`unRegionalGroup` 联合国区域组；`idd` 电话区号组成；`altSpellings` 别名数组；`landlocked` 是否内陆；`borders` 相邻代码数组；`demonyms` 居民称谓；`flag` Unicode 字符不是本包图像。

导入版字段：`cca3, cca2, name_en, name_zh, capital, region, subregion, latlng, area_km2, independent, un_member`。地区层级和译名照录上游，未自动背书。

## elements

原始为 `{"elements":[...]}`；导入版是元素数组。主键 `number`（原子序数），`symbol` 元素符号，`name` 英文名，`category` 上游元素分类，`atomic_mass` 原子质量数值，`period/group` 周期/族，`phase` 物态，`shells` 各电子层数目数组；`source` 单项文字来源。

`melt/boil` 为 K；`density` 的单位取决于物态，因此优先读 `density_unit` 或统一的 `density_g_cm3`（g/cm³）。`molar_heat` J/(mol·K)；`appearance` 外观说明；`discovered_by/named_by` 人名文本。`electron_configuration` 电子排布；`electron_configuration_semantic` 简写（星号可表示未确认）；`electron_affinity`、`ionization_energies` 能量属性，单位/约定见上游 README；`electronegativity_pauling` 鲍林电负性；`atomic_radii` 按定义分类的 pm 半径数组；`block` 区块。

`xpos/ypos/wxpos/wypos` 表格布局坐标；`cpk-hex` 色彩；`summary` Wikipedia 摘要；`bohr_model_image/bohr_model_3d/spectral_img/image` 是外链或附带署名的媒体元信息，未下载媒体。导入版删除这些非必需字段，仅保留 1–118 号及 13 个明确字段。原始 119 号数据仅供溯源，不应作为已确认元素教学。

## CMUdict

原始 `cmudict.dict` 每行：`词条 音素 音素 ...`，可有 `#` 后的注释。原始 `.phones` 是 39 个基础音素及音类；`.symbols` 为合法音素符号表（带重音数字）。

导入 CSV 五列：

- `entry`：原始键，如 `a`、`a(2)`；主键。
- `word`：去除末尾读音序号后的拼写；用于课程词表连接，不是唯一键。
- `variant`：整数，未带序号的读音为 1，带 `(n)` 的为 n。
- `phonemes`：空格分隔 ARPAbet 字符串，不是 IPA；0 无重音、1 主重音、2 次重音。
- `note`：保留行内 `#` 后注释。

不包含词义、翻译、音频、音节划分、词频、课程年级。英语/美式发音并不等于教材要求的唯一发音。

## HYG v4.2

原始 CSV 压缩为 gzip；具名子集 CSV 保留全部 37 列、按原顺序；主键 `id` 是本库编号。`proper` 为常用名，具名子集的筛选只表示有名称，**不是儿童白名单**。

- 目录交叉编号：`hip, hd, hr, gl`；名称/标识：`bf, proper, bayer, flam, con`（星座标准缩写）。
- `ra` 赤经小时，`dec` 赤纬度；J2000.0 参考。`rarad/decrad` 为弧度版本。
- `dist` 秒差距；乘 3.262 近似光年；`>=100000` 是缺失或可疑视差标志，应显示未知而不是数值距离。
- `pmra/pmdec` 毫角秒/年；`pmrarad/pmdecrad` 弧度/年；`rv` 径向速度 km/s。
- `mag` 视星等；`absmag` 绝对星等；`spect` 光谱分类；`ci` 色指数。
- `x/y/z` 赤道坐标系笛卡尔位置（秒差距）；`vx/vy/vz` 相应速度（秒差距/年）。
- `comp/comp_primary/base` 多星系统组件信息。
- `lum` 太阳光度倍数；`var` 变星标识；`var_min/var_max` 视星等变化范围。

太阳 `id=0, proper=Sol` 保留在原表和具名子集中；不要用 `dist=0` 做除数。版本 v4.2 不是当前观测时刻的天球坐标。归档 README 的字段说明与官网详情交叉核查，但未校核每条天体数据。
