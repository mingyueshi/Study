# 多学科基础数据首批（2026-11-02 核验）

这是为小学阶段家庭学习系统准备的**开放许可基础数据**，不是课程教材或经过儿童内容认证的题库。`raw/` 保留原始数据和上游许可，`derived/` 是便于导入的明确变换结果；各数据集的独立许可继续有效，不给整个包套用单一新许可。未运行任何下载仓库的代码。

| 目录 | 原始数据 | 辅助导入数据 | 用途与边界 |
|---|---:|---:|---|
| countries | 250 个国家/地区条目，JSON | 250 条核心字段 JSON | 中英名称、地区、首都、坐标、面积；250 不是主权国家数，不含地图几何或旗帜图片 |
| elements | 119 条，JSON | 118 条 `elements_1_118.json` | 元素符号/物态/周期/质量等卡片；原库含未确认的 119 号，导入文件已排除 |
| cmudict | 135,166 条读音记录，文本 | 等量 CSV | 美式英语 ARPAbet 发音查询；不是中文词义词典、音频库或小学词表 |
| hyg | 119,626 条星表记录，CSV.gz | 499 条具名记录 CSV（含太阳） | 恒星/星座检索与可视化；不是实时观测或高精度导航资料 |

## 导入优先级

1. 先将所有资源放入**后台资源库**，`review_status=unreviewed`，不自动曝光给儿童。
2. 地理和元素优先用 `derived/`；中文译名、单位、年龄与课程映射另行审核。元素文件没有中文名称。
3. 英语用家长/教师确认的课程词表做**白名单连接**，仅查所需单词发音；严禁从全量 CMUdict 随机抽词直接给儿童。完整词库含成人/冒犯/专名等词条，未做适龄过滤。
4. 天文先用 499 条具名子集做兴趣卡片；需要中文常用名映射。完整原表用 gzip 解压后按 CSV 读取，压缩文件约 13.64 MB，解压后约 33.93 MB。

## 许可与来源

- **countries**：mledoze/countries，ODbL 1.0。保留署名、许可和来源；分发改编数据库应按 ODbL 条款处理。上游特别声明旗帜不受 ODbL 许可覆盖。本包没有旗帜图像或地图图像。
- **elements**：Bowserinator/Periodic-Table-JSON，CC BY-SA 3.0。改编数据继续按相应许可处理。原始 JSON 外链媒体不是随包获得的媒体授权，不应自动下载展示。
- **cmudict**：Carnegie Mellon University / cmusphinx，原始 LICENSE 是两条款 BSD 风格许可，保留版权声明、条件和免责声明；不简化成“无版权”。
- **hyg**：作者 Astronomy Nexus / David Nash 发布的 v4.2，CC BY-SA 4.0。数据直接来自作者官网公开版本 URL，并以 SHA256 固定本次快照。GitHub 已归档；其字段说明与 LICENSE 另标来源，不能误认 v4.2 有 GitHub commit。官网声明 v4.2 是其当前版，但本包不声称是最新最全恒星观测。

每项的固定提交/版本、源 URL、时间、字节数、字段、条数、哈希和质量缺口在 `metadata.json`。`source_index.csv` 可供人工清点；`FIELDS.md` 提供主要字段语义。各资源保留上游 LICENSE 文件，不移除署名。

## 质量与安全审核边界

进行了 JSON/CSV/gzip 可解析、主键重复、条数、音素合法性、大小、SHA256 核验；**没有逐条事实核验、课程对应、中文翻译或儿童适龄人工审校**。数值缺失不应填成 0；星表异常距离不能解释为实测值；地理归类不能被当成争议地区地位裁决。加载数据时当作普通文本解析，不能把数据字段当成 HTML 或脚本执行。若未来公开发布、商业使用或下载外链媒体，需再核对相应许可与第三方权利。

## 关键核验链接

- https://github.com/mledoze/countries
- https://github.com/Bowserinator/Periodic-Table-JSON
- https://iupac.org/what-we-do/periodic-table-of-elements/
- https://github.com/cmusphinx/cmudict
- https://www.astronexus.com/projects/hyg
- https://www.astronexus.com/projects/hyg-details

## 未采用 / 下载边界

`datasets/country-codes` 虽声明 PDDL，但 README 同时提醒 ISO 等原始来源权利不清；本批未采用。HYG 官方 Codeberg 的 web 抓取被 robots 限制，未绕过；作者官网明确公开的版本文件可正常下载，已检查 gzip 格式与全量解析成功。未抓取任何付费题库、登录受限教材、盗版资料，也未绕过 DRM。
